/**
 * 
 */
package edu.ics211.h11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author ausui
 *
 */
class HuffmanTest { 
  private String inString;
  
  /**
   * @throws java.lang.Exception
   */
  @BeforeEach
  void setUp() throws Exception {
    this.inString = "";
    try {
    inString = new String(Files.readAllBytes(Paths.get("Aubrie.txt")));
    System.out.println(inString);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


  @Test
  void test() throws IOException {
    //check if args.length == 0
    if (inString == null) {
      //syso usage message
      System.out.println("Usage: java H11Huffman <filename>");
      throw new FileNotFoundException();
      //else check if filename ends in Huffman.HUFF_Ext
    } else {
      int index = inString.indexOf(Huffman.HUFF_EXT);
      //if it is, then create output filename
      if (index != -1) {
        String outputName = inString.substring(0, index);
        System.out.println(outputName);
        //create input stream 
        FileInputStream input = new FileInputStream(inString);
        // create output stream 
        FileOutputStream output = new FileOutputStream(outputName);
        //call Huffman.decompress(input, output)
        Huffman.decompress(input, output);
        Huffman.compress(input, output);
        System.out.println();
        //flush and close output stream 
        output.flush();
        output.close();
      }
    }
  }
  
}
