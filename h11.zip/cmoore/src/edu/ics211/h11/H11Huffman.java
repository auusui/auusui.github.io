package edu.ics211.h11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class H11Huffman {

  public H11Huffman() {
    // TODO Auto-generated constructor stub
  }

  /**
   * 
   * @param args
   */
  public static void main(String[] args) throws IOException {
    //check if args.length == 0
    if (args.length == 0) {
      //syso usage message
      System.out.println("Usage: java H11Huffman <filename>");
      throw new FileNotFoundException();
      //else check if filename ends in Huffman.HUFF_Ext
    } else {
      int index = args[0].indexOf(Huffman.HUFF_EXT);
      //if it is, then create output filename
      if (index != -1) {
        String outputName = args[0].substring(0, index);
        System.out.println(outputName);
        //create inputstream 
        FileInputStream input = new FileInputStream(args[0]);
        // create output stream 
        FileOutputStream output = new FileOutputStream(outputName);
        //call Huffman.decompress(input, output)
        Huffman.decompress(input, output);
        //flush and close output stream 
        output.flush();
        output.close();
      }

    }
   
   
    
  }
}
